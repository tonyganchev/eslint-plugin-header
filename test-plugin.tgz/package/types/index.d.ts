export = pluginDefinition;
/** @type {import("eslint").ESLint.Plugin} */
declare const pluginDefinition: import("eslint").ESLint.Plugin;
//# sourceMappingURL=index.d.ts.map