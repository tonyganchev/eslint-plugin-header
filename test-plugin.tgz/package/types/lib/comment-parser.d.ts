declare function _exports(commentText: string): [import("./rules/header").CommentType, string[]];
export = _exports;
//# sourceMappingURL=comment-parser.d.ts.map