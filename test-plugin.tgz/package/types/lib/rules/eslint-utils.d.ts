declare namespace _exports {
    export { RuleContext, SourceCode };
}
declare namespace _exports {
    function contextSourceCode(context: RuleContext): SourceCode;
}
export = _exports;
type RuleContext = import("eslint").Rule.RuleContext;
type SourceCode = import("eslint").SourceCode;
//# sourceMappingURL=eslint-utils.d.ts.map