export { headerRule as header };
export type NodeListener = Rule.NodeListener;
export type ReportFixer = Rule.ReportFixer;
export type RuleFixer = Rule.RuleFixer;
export type RuleContext = Rule.RuleContext;
/**
 * The sequence of characters that define
 * the end of a line.
 */
export type LineEnding = "\n" | "\r\n";
/**
 * Matching rule for a line from the header
 * using regular expression and optionally providing an auto-fix replacement.
 */
export type HeaderLinePattern = {
    /**
     * A regular expression that should match
     * the header line.
     */
    pattern: string | RegExp;
    /**
     * When set, if the actual header line does not
     * match `pattern`, this value is to be used when running auto-fix.
     */
    template?: string | undefined;
};
/**
 * Matching rule for
 * a single line of the header comment or the header comment as a whole if only
 * one used.
 */
export type HeaderLine = string | RegExp | HeaderLinePattern;
/**
 * The set of header comment-
 * matching rules.
 */
export type HeaderLines = HeaderLine | HeaderLine[];
/**
 * Defines what EOL
 * characters to expect - either forced to be Windows / POSIX-compatible, or
 * defaulting to whatever the OS expects.
 */
export type LineEndingOption = "os" | "unix" | "windows";
/**
 * How to treat
 * line endings.
 */
export type HeaderSettings = {
    lineEndings?: LineEndingOption;
};
/**
 * The expected type of comment to use
 * for the header.
 */
export type CommentType = "block" | "line";
/**
 * Header content configuration defined in a
 * separate JavaScript template file.
 */
export type FileBasedConfig = {
    /**
     * Template file path relative to the directory
     * from which ESLint runs.
     */
    file: string;
    /**
     * Encoding to use when reading the
     * file. If omitted, `"utf8"` will be assumed.
     */
    encoding?: BufferEncoding | undefined;
};
/**
 * Header content configuration defined inline
 * within the ESLint configuration.
 */
export type InlineConfig = {
    /**
     * The type of comment to expect.
     */
    commentType: CommentType;
    /**
     * Matching rules for lines. If only one rule
     * is provided, the rule would attempt to match either the first line ar all
     * lines together.
     */
    lines: HeaderLine[];
};
/**
 * Rule configuration on the handling of
 * empty lines after the header comment.
 */
export type TrailingEmptyLines = {
    /**
     * If set, the rule would check that at least
     * a `minimum` number of EOL characters trail the header.
     */
    minimum?: number | undefined;
};
export type HeaderOptionsWithoutSettings = {
    /**
     * The text matching rules
     * for the header.
     */
    header: FileBasedConfig | InlineConfig;
    /**
     * Rules about empty lines
     * after the header comment.
     */
    trailingEmptyLines?: TrailingEmptyLines | undefined;
};
/**
 * Modern
 * object-based rule configuration.
 */
export type HeaderOptions = HeaderOptionsWithoutSettings & HeaderSettings;
export type LegacyFileBasedConfig = [template: string];
export type LegacyFileBasedSettingsConfig = [template: string, settings: HeaderSettings];
export type LegacyInlineConfig = [type: CommentType, lines: HeaderLines];
export type LegacyInlineSettingsConfig = [type: CommentType, lines: HeaderLines, settings: HeaderSettings];
export type LegacyInlineMinLinesConfig = [type: CommentType, lines: HeaderLines, minLines: number];
export type LegacyInlineMinLinesSettingsConfig = [type: CommentType, lines: HeaderLines, minLines: number, settings: HeaderSettings];
/**
 * Full possible rule configuration options.
 */
export type AllHeaderOptions = [HeaderOptions] | LegacyFileBasedConfig | LegacyFileBasedSettingsConfig | LegacyInlineConfig | LegacyInlineSettingsConfig | LegacyInlineMinLinesConfig | LegacyInlineMinLinesSettingsConfig;
/**
 * Rule
 * configuration array including severity.
 */
export type HeaderRuleConfig = Linter.RuleEntry<AllHeaderOptions>;
/** @type {Rule.RuleModule} */
declare const headerRule: Rule.RuleModule;
import type { Rule } from "eslint";
import type { Linter } from "eslint";
//# sourceMappingURL=header.d.ts.map