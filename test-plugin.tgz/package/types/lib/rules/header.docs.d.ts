export const description: "The rule validates that the source file starts with a specific header comment pattern.";
export const recommended: true;
//# sourceMappingURL=header.docs.d.ts.map