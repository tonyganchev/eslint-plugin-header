export type lineEndingOptions = string;
/**
 * @enum {string}
 */
export const lineEndingOptions: Readonly<{
    os: "os";
    unix: "unix";
    windows: "windows";
}>;
export type commentTypeOptions = string;
/**
 * @enum {string}
 */
export const commentTypeOptions: Readonly<{
    block: "block";
    line: "line";
}>;
/** @type {import("json-schema").JSONSchema4} */
export const schema: import("json-schema").JSONSchema4;
//# sourceMappingURL=header.schema.d.ts.map